<?php $__env->startSection('content'); ?>

<form method="post" action="<?php echo e(route('get.enroled.classes')); ?>">
	<?php echo e(csrf_field()); ?>

	<div class="col-md-12">
		

		<div class="col-md-6">
			<select class="form-control" name="sessionid">
			<?php $__currentLoopData = $session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	}
				
<option value="<?php echo e($session->id); ?>">
	<?php echo e($session->name); ?>


</option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>

		<div class="col-md-6">
			<button class="btn btn-success">Continue</button>
		</div>
	</div>


</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>