<?php $__env->startSection('content'); ?>

<div class="col_3">
        	<?php $__currentLoopData = $allsubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <a href="<?php echo e(route('all.students',[$sub->section_id,$sessionid,$sub->class_id,$sub->subject->id,])); ?>">
            <div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left   fa fa-credit-card icon-rounded"></i>
                    <div class="stats">
                    	
                      <span style="color:blue">Class=<?php echo e($sub->schoolClass->name); ?></span>
                     
                      <span style="color:green">Section=<?php echo e($sub->section->name); ?></span>
                      <span>Subject=<?php echo e($sub->subject->name); ?></span>
                    </div>
                </div>
                <br>
        	</div>
</a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        	<div class="clearfix"> </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>