<?php $__env->startSection('content'); ?>

<div class="col_3">
        	<?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <a href="<?php echo e(route('all.teacher.subjects', [$class->schoolClass->id, $sessionid])); ?>">
            <div class="col-md-3 widget widget1">
        		<div class="r3_counter_box">
                    <i class="pull-left   fa fa-credit-card icon-rounded"></i>
                    <div class="stats">
                    	
                     
                      <span><?php echo e($class->schoolClass->name); ?></span>
                    </div>
                </div>
                <br>
        	</div>
</a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        	<div class="clearfix"> </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>