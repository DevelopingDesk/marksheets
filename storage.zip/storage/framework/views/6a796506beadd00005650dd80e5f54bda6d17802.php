<?php $__env->startSection('content'); ?>
<style> 
input[type=number] {
   
    padding: 12px 20px;
    margin: 4px 0;
    box-sizing: border-box;
    border: none;
    border-bottom: 2px solid lightblue;
    
}
</style>



<div style="background-color: white">
<h2 style="text-align: center;">Enter Student Marks</h2>


   <div class="col-md-12">
    <div class="col-md-4" style="border:2px solid lightblue;border-radius: 15px">
    <input type="date" name="date" id="date" class="form-control" style="border:2px solid red" required="true" >
  </div>
  <div class="col-md-4" style="border:2px solid lightblue;border-radius: 15px">
    <input type="text" name="total" id="totalmarks" placeholder="Enter Total Marks" class="form-control" style="border:2px solid red" >
  </div>
  <input type="hidden" id="subjectid" name="subjectid" value="<?php echo e($subjectid); ?>">
  <div class="col-md-4" style="border:2px solid lightblue;border-radius: 15px">
   <select class="form-control testtype">
    

     <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

     <option value="<?php echo e($exa->id); ?>" ><?php echo e($exa->name); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </select>
  </div>
  
</div>
<br>
<br>
<br>

   
<table id="myTable"  class="table table-striped table-bordered" cellspacing="100" width="100%">
        <thead >
            <tr>
                <th>Student Name</th>
                 <th>Father Name</th>
                 <th>Class</th>
                 <th>Session</th>
                 <th>Obtained Marks</th>
                 <th>Action</th>
            
                
            </tr>
        </thead>
       
        <tbody>
            <?php $__currentLoopData = $allstudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $students): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td class="studentname"><?php echo e($students->name); ?> <input type="hidden" class="studentid" value="<?php echo e($students->id); ?>" ></td>
                <td class="fathername"><?php echo e($students->fatherName); ?></td>
                
                <td><?php echo e($students->schoolClass->name); ?> <input type="hidden" name="classid" value="<?php echo e($students->schoolClass->id); ?>"></td>
                <td><?php echo e($students->session->name); ?> <input type="hidden" name="sessionid[]" value="<?php echo e($students->session->id); ?>"></td>
               
               <td  ><input class="obtainedmarks" type="text"   placeholder="Enter marks here"></td>
                <td><button class="btn-primary btnSelect">Select</button></td>

            
               
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  


</script>



<script type="text/javascript" src="<?php echo e(asset('js/Marks/marks.js')); ?>"></script>
<script type="text/javascript">
var token='<?php echo e(Session::token()); ?>';
var add='<?php echo e(route('marks.store')); ?>';

</script> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Dashboard/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>